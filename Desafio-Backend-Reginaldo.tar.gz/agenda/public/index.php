<?php

/*
Desenvolvedor: Reginaldo
Desafio Backend: API REST Agenda de Compromissos usando framework PhalconPHP
*/

use Phalcon\Loader;
use Phalcon\Mvc\Micro;
use Phalcon\Mvc\Model;
//use Phalcon\Mvc\View;
//use Phalcon\Mvc\Application;
use Phalcon\Di\FactoryDefault;
use Phalcon\Mvc\Url as UrlProvider;
use Phalcon\Db\Adapter\Pdo\Mysql as DbAdapter; 
use Phalcon\Http\Response;

header("Content-Type: text/html; charset=utf-8");

  try {
     //Registra o autoloader
     $loader = new Loader();
     $loader->registerDirs(array(
	"../app/controllers/",
        "../app/models/"
     ))->register();

    //Cria o DI
    $di = new FactoryDefault();   

    //Setup the database service
    $di->setShared("db", function() {
         $db =  new DbAdapter(array(
             "host"     => "localhost",
             "username" => "root",
             "password" => "admin",
             "dbname"   => "agendacompromissos",
             "charset" => "utf8"
            ));
         return $db;
      });
    
    //Setup the view component
    /*$di->set("view", function(){
       $view = new View();
       $view->setViewsDir("../app/views/");
       return $view;
    });*/

    //Setup a base URI so thal tall generated URIs include the projetoPhalcon folder
    /*$di->set("url", function() {
       $url = new UrlProvider();
       $url->setBaseUri("/agenda/");
       return $url;
    }); */
   
   //Handle the request
   $app = new Micro($di);
   
   $app->get("/", function() {
      echo "<h1>Parabéns!</h1>";
      echo "<p>Você conseguiu executar o projeto base. </p>";
   });

   $app->get("/welcome/{name}", function ($name) {
      echo "Welcome $name!";
   });

   $app->get("/agenda/{id:[0-9]+}", function($id) use ($app) {
      //filtro por id (chave primária auto increment)
       echo "pesquisa por filtro id $id <br> ";
     
      $agenda = Agenda::findFirst($id);

      $response = new Response();

     if ($agenda == false) {
         $response->setJsonContent(
            array("status" => "NOT-FOUND!")
         );
     }
     else {
         $response->setJsonContent(
             array(
                "status" => "FOUND",
                "data"   =>  array(
                "id" => $agenda->id,
                "data" => $agenda->data,
                "horario" => $agenda->horario,
                "local" => $agenda->local,
                "task" => $agenda->task
             )
          )
         );
     }
      return $response;

   });

   $app->post("/agenda", function() use ($app) {
      //adiciona um novo compromisso na agenda
      echo "cadastro de compromissos na agenda <br>";
      
      $response = new Response();
      $ag = $app->request->getJsonRawBody();
      $agenda = new Agenda();
      $agenda->create(array(
           "data" => $ag->data,
           "horario" => $ag->horario,
           "local" => $ag->local,
           "task" => $ag->task
         ));

     if($agenda != false) {
       $response->setStatusCode(201,"Created");
       //$agenda->id = $status->getModel()->id;
       $response->setJsonContent(
          array(
            "status" => "OK",
            "data" => $agenda
            )
       );
     }
     else {
       $response->setStatusCode(409,"Conflit");
       $errors = array();
       foreach($status->getMessages() as $message) {
          $errors[] = $message->getMessage();
       } 
       $response->setJsonContent(
          array(
               "status" => "ERROR",
               "messages" => $errors
              )
         ); 
     }
      return $response;
   });

   $app->put("/agenda/{id:[0-9]+}", function($id) use ($app) {
      //atualiza um compromisso pelo filtro id
      echo "atualiza o $id da agenda de compromisso \n";
      $response = new Response();
      $ag = $app->request->getJsonRawBody();
      $agenda = new Agenda();
      //$agenda = Agenda::findFirst($id); 
      $agenda->update(array(
            "data" => $ag->data,
            "horario" => $ag->horario,
            "local" => $ag->local,
            "task" => $ag->task
           ));      

      if($agenda == false) {
         $response->setJsonContent(
             array("status" => "NOT FOUND!")
         );
      }
      else {
         $response->setJsonContent(
           array(
             "status" => "OK",
             "data" => $agenda
             )
        );

    }
      return $response;
      
   });

   $app->delete("/agenda/{id:[0-9]+}", function($id) use ($app) {
      //exclui um compromisso da agenda
      echo "exclui um compromisso da agenda id $id <br>";
   
   	$agenda = Agenda::findFirst($id);
   	if($agenda != false) {
      		if($agenda->delete() == false) {
        	    echo "$id não encontrado no banco de dados \n";

         	foreach($agenda->getMessages() as $message) {
             	    echo $message, "\n";
         	}
      	  }
      	  else {
         	echo "$id deletado \n";
      	  }
       }
  });
  
   $app->notFound(function() use ($app) {
      $app->response->setStatusCode(404,"Not Found")->sendHeaders();
      echo "OPS Não existe a página solicitada!<br>";
   });
   $app->handle();

   //echo $application->handle()->getContent();


  } catch(\Exception $e) {
    echo "PhalconException: ", $e->getMessage();
  }

?>
