<?php

use Phalcon\Mvc\Controller;
use Phalcon\Mvc\Model\Query;

class AgendaController extends Controller
{

   public function indexAction()
   {
   }

   public function addAction()
   {
       $query = "INSERT INTO agenda(data,horario,local,task)"
               . "VALUES(:data:,:horario:,:local:,:task:)";
       $agenda = $query->execute(); 
       
   }

   public function findAllAction()
   {
       $query = new Query("SELECT * FROM agenda", $this->getDI());
       $agenda = $query->execute();      
   }

   public function findByIdAction($id)
   {
       $query = new Query("SELECT * FROM agenda WHERE id = :id:");
       $agenda = $query->execute();
     
   }

   public function updateAction($id)
   {
      $query = new Query("UPDATE agenda SET data = :data:, horario = :horario:, local = :local:, task = :task: WHERE id = :id:");
      $agenda = $query->execute();
    
   }
}
?>
