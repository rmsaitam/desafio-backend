<?php

use Phalcon\Mvc\Model;

class Agenda extends Model
{
   public $id;
   public $data;
   public $horario;
   public $local;
   public $task;

   public function getSource()
   {
      return "agenda"; //nome da tabela
   }
   
}
?>
