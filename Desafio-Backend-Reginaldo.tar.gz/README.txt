E aí, beleza? Se você está querendo trabalhar em um ambiente descontraído, fazendo o que gosta e compartilhando conhecimento, este desafio é pra você! :)
  
 #### Objetivo:
 +Desenvolver uma API REST para uma aplicação de Agenda de Compromissos.
  
 #### Estrutura:
API REST utilizando framework Phalcon PHP.

Banco exportado e localizado em database\db-agendacompromissos.sql
IMPORTAR A BASE
1. Cria o banco
2. mysql -h localhost -u user -D bancoCriado < db-agendacompromisso.sql

Compartilhei no blog o howto de configuração do ambiente PHP com framework PhalconPHP 
http://mundodacomputacaointegral.blogspot.com.br/2016/03/configurando-o-ambiente-desenvolvimento-php-com-framework-phalcon.html

Foi criado o VirtualHost agenda.conf no Apache, copiar para /etc/apache2/sites-available/ no caso em Debian
Habilitar o VirtualHost agenda
#a2ensite agenda
Reload do Apache
#service apache2 reload

Testes realizados com curl pelo terminal
PESQUISA
curl -i -X GET http://localhost/agenda/agenda/1
HTTP/1.1 200 OK
Date: Mon, 07 Mar 2016 01:21:54 GMT
Server: Apache/2.4.10 (Debian)
X-Powered-By: PHP/5.6.17-0+deb8u1
Vary: Accept-Encoding
Content-Length: 137
Content-Type: text/html; charset=utf-8

pesquisa por filtro id 1 <br> {"status":"FOUND","data":{"id":"1","data":"05\/03\/16","horario":"15:30","local":"home","task":"homework"}}

INSERÇÃO
curl -i -X POST -d '{"data":"06-03-16","horario":"22:10","local":"home","task":"teste"}' http://localhost/agenda/agenda

EXCLUSÃO
curl -i -X DELETE http://localhost/agenda/agenda/3

ATUALIZA
curl -i -X PUT -d '{"horario":"20:50"},"task":"teste123"}' http://localhost/agenda/agenda/6
